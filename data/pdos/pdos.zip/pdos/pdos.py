# -*- coding: utf-8 -*-
"""
请使用以下代码生成原子速度轨迹文件：
#############################################################################
dump dump_id dump_group custom 1 dump.lammpstrj id type vx vy vz
dump_modify dump_id sort id
#############################################################################
@author: benward (hityingph@163.com)
"""
import numpy as np
import matplotlib.pyplot as plt
import time
import os


# Calculate the vacf from velocity data
# 计算速度自关联函数(vacf)和声子态密度(pdos)
def find_pdos(v_all, Nc, dt, omega, fileName):

    file_vacf_npy = fileName + "_vacf.npy"
    file_pdos_npy = fileName + "_pdos.npy"

    start_date = time.time()
    "The oringal code was written in Matlab by Fan Zheyong"
    # v_all: 速度数据，三维：计算次数、原子数、速度向量（可以是只有z轴速度[vz]，也可以是多个[vx, vy, vz]）
    # Nc: 自相关速度计算次数
    # dt: 两帧之间的速度（模拟时，每一步都保存了速度信息，所以也就是模拟时每步时间间隔）, 单位为ps
    # omega: phonon angular frequency points you want to consider
    Nf = v_all.shape[0]  # number of frames
    M = Nf - Nc  # number of time origins for time average
    vacf = np.zeros(Nc)  # the velocity autocorrelation function (VACF)
    for nc in range(Nc):  # loop over the correlation steps
        ratio = (nc + 1) / Nc * 100
        print("PDOS计算进度：%.2f%%" % ratio)
        for m in range(M + 1):  # loop over the time origins
            delta = np.sum(v_all[m + 0] * v_all[m + nc])
            # print(delta)
            vacf[nc] = vacf[nc] + delta
    # VACF归一化
    vacf = vacf / vacf[0]
    # 修改前复制以下
    np.save(file_vacf_npy, vacf)

    print(time.time() - start_date)

    # window function
    vacf = vacf * (np.cos(np.pi * np.arange(Nc) / Nc) + 1) * 0.5
    # C(t) = C(-t)
    vacf = vacf * np.append(np.ones(1), 2 * np.ones(Nc - 1)) / np.pi
    # 声子态密度 the phonon density of states (PDOS)
    pdos = np.zeros(len(omega))
    # 傅里叶变换 Discrete cosine transform
    for n in range(len(omega)):
        pdos[n] = dt * sum(vacf * np.cos(omega[n] * np.arange(Nc) * dt))

    print(time.time() - start_date)

    np.save(file_pdos_npy, pdos)

    return file_vacf_npy, file_pdos_npy


def rebuild_data(N, num_frame, file_name="data", skiprows=9):
    # N:原子数
    # num_frame：计算次数
    start_date = time.time()
    # 读取lammps的dump输出数据，保存z轴速度，计算声子态密度
    # lammps的in文件dump数据输出时，按照原子id排个序："dump_modify dump_id sort id"
    # 只算z轴速度
    v_all = np.zeros((num_frame, N, 3))
    fin = open(file_name + ".lammpstrj", "r")
    for i in range(num_frame):
        ratio = (i + 1) / num_frame * 100
        print("数据读取进度：%.2f%%" % ratio)
        # 每一步都保存链原子速度等信息，并且有9行说明信息，跳过
        for j in range(skiprows):
            fin.readline()
        for k in range(N):
            line = fin.readline().split()[2:5]
            vz = [float(l) for l in line]
            v_all[i, k] = vz
    print(time.time() - start_date)
    np.save(file_name + ".npy", v_all)
    print(time.time() - start_date)

    return file_name + ".npy"


def get_atom_n(file_name="data"):
    n = -1
    fin = open(file_name + ".lammpstrj", "r")
    for j in range(4):
        s = fin.readline()
        if (j == 3):
            n = int(s.strip())
    print(n)
    return n


def plt_pdos(t, vacf, nu, pdos, save_fig_name="pdos.png", onlyPDOS=False):

    if (not onlyPDOS):
        plt.subplot(1, 2, 1)
        plt.plot(t, vacf)
        plt.xlabel("Correlation Time (ps)")
        plt.ylabel("Normalized VACF")

        plt.subplot(1, 2, 2)

    plt.plot(nu, pdos)
    plt.xlabel("$\omega$ (THz)")
    plt.ylabel("PDOS")

    if (save_fig_name is not None):
        plt.savefig(save_fig_name)
    # plt.show()


def run(fileNames, reload_vs=False, reload_pdos=False, onlyPDOS=True):

    for i in range(len(fileNames)):
        fileName = fileNames[i]
        N = get_atom_n(fileName)

        # innt 12160
        # innernt 10880
        # gvdos 2560
        # set up some parameters related to the MD simulation
        # fileName = "4040CNT_20nm_voutput_all_gvdos"  # 待读取的dump输出文件
        # N = 2560  # 纳米管中间的一部分输出了速度等数据，这部分原子数，可以在dump输出的文件中看到

        Nf = 5000  # dump输出时模拟了多少步

        Nc = 500  # 速度自关联部数 (数字越大，分辨率越高)
        dt = 0.001  # lammps模拟的时间间隔，单位ps (它的倒数大约是能达到的最大频率)
        omega = np.arange(1, 380.5, 0.5)  # 角频率，单位THz
        nu = omega / 2 / np.pi
        # omega = 2 * pi * nu, while nu is the frequency range
        # 帧数，也就是计算步数，lammps每一步都保存了数据
        num_frame = Nf

        # 把dump输出的速度数据，转化一下，保存为numpy文件，方便读取，运行一次就好
        file_path_npy = fileName + ".npy"
        if (reload_vs or not os.path.exists(file_path_npy)):
            file_path_npy = rebuild_data(N, num_frame, fileName)

        print("载入vs数据：" + file_path_npy)
        start_date = time.time()
        v_all = np.load(file_path_npy)
        print(np.shape(v_all))

        # 只要z轴
        v_all = v_all[:, :, 2:]
        print(np.shape(v_all))
        print("用时：%.5f" % (time.time() - start_date))

        file_vacf_npy = fileName + "_vacf.npy"
        file_pdos_npy = fileName + "_pdos.npy"

        if (reload_pdos or not os.path.exists(file_pdos_npy)):
            find_pdos(v_all, Nc, dt, omega, fileName)

        print("载入pdos数据：" + file_pdos_npy)
        start_date = time.time()
        vacf = np.load(file_vacf_npy)
        pdos = np.load(file_pdos_npy)
        print("用时：%.5f" % (time.time() - start_date))

        # The discrete correlation time
        t = np.arange(Nc) * dt

        plt_pdos(t, vacf, nu, pdos, onlyPDOS=onlyPDOS)


run(["4040CNT_20nm_voutput_all"])
