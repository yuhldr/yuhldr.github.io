详细见 [速度自关联函数与声子态密度](https://yuhldr.github.io/posts/685bd07.html)

```bash
mpirun -np 12 lmp -in file.lmp
```

```bash
vacf -dt 1e-3 -fr 0 60 -oa acf.txt -od dos.txt dump.vc
```

```bash
python cnt.py
```

结果

| x                       | y                       | x                       | xyz                     |
| ----------------------- | ----------------------- | ----------------------- | ----------------------- |
| ![alt text](acf-0.png)  | ![alt text](acf-1.png)  | ![alt text](acf-2.png)  | ![alt text](acf-3.png)  |
| ![alt text](pdos-0.png) | ![alt text](pdos-1.png) | ![alt text](pdos-2.png) | ![alt text](pdos-3.png) |
