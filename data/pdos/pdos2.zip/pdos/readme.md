详细见 [速度自关联函数与声子态密度](https://yuhldr.github.io/posts/685bd07.html)

```bash
mpirun -np 12 lmp -in file.lmp
```

```bash
vacf -dt 1e-3 -fr 0 60 -oa acf.txt -od dos.txt dump.vc
```

```bash
python cnt.py
```
