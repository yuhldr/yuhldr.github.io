'计算与对比'

import os

import numpy as np
from matplotlib import pyplot as plt

from utils import cal_vacf, get_dt, read_log, vacf2pdos


def main(reload=False):
    """测试
    """
    n = 0

    acf_lk = np.loadtxt("acf.txt")
    plt.plot(acf_lk[:, 0], acf_lk[:, n+1], "s", zorder=1, label="VACF_PDOS")

    if not os.path.exists("acf-py.npy") or reload:
        dts, acf = cal_vacf("dump.vc")
        np.save("acf-py.npy", acf)
    else:
        acf = np.load("acf-py.npy")
        dts = get_dt(acf.shape[0])
    plt.plot(dts, acf[:, n], "^",  zorder=2, label="VACF_PDOS-py")

    ys = []
    for d in read_log("log.lmp")[2:]:
        ys.append(d["mat"][:, n+1])
    vacf_log = np.mean(ys, 0)
    vacf_log = vacf_log/vacf_log[0]
    plt.plot(get_dt(len(vacf_log)),
             vacf_log, ".-", zorder=3, label="LAMMPS-log")

    plt.legend()
    plt.savefig("acf.png")
    plt.show()
    plt.close()

    dos = np.loadtxt("dos.txt")
    plt.plot(dos[:, 0], dos[:, n+1], "s", zorder=1, label="VACF_PDOS")

    a, b = vacf2pdos(vacf=acf[:, n], fs_max=60)
    plt.plot(a, b, "^",  zorder=2, label="VACF_PDOS-py")

    a, b = vacf2pdos(vacf=vacf_log, dt=0.001, fs_max=60)
    plt.plot(a, b, ".-", zorder=3, label="LAMMPS-log")
    plt.legend()
    plt.savefig("pdos.png")
    plt.show()


main()
