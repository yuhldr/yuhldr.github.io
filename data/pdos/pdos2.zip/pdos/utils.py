'解析log与dup数据'
import re
import time

import numpy as np
from scipy.fft import dct
from scipy.fftpack import fft, ifft

LOG_RE_RUN_DATA = r"^\s*((-?[0-9]*(\.[0-9]*)?([eE][-]?)?[0-9]+)\s+)+(-?[0-9]*(\.[0-9]*)?([eE][-]?)?[0-9]+)?"
LOG_RE_RUN_STEP = r"^[\s]*run[\s]+(\d+)[\s]*"
LOG_RE_LOCATE_BLOCKS = r"\brun[\s]+\d+\b[\s\S]*?\bDangerous\sbuilds\b"
LOG_RE_MODEL_PATH = r"\s*read_data\s+(.*?)\s*\n"


RE_DUMP_DATA = r"ITEM:\s+ATOMS\s+(.*?)\n"
RE_RUN_STEP = r"ITEM:\s+TIMESTEP\s*\n(\d*)\s*\n"
RE_NU_ATOM = r"ITEM:\s+NUMBER\s+OF\s+ATOMS\s*\n(\d*)\s*\n"
ZERO = 1e-12


def read_dumps(file_path, steps=None):
    """读取输出的坐标等信息的文件（每一步都放在一个文件）
    dump d1 all custom 1 xyz.dat id x y z type vx vy vz
    dump_modify d1 sort id

    Args:
        file_path (_type_): _description_
        steps (list, optional): 只读取某几个输出. Defaults to None.
    """
    data = {}
    start_time = time.time()
    print(file_path)

    with open(file_path, "r", encoding="utf8") as file:
        file_str = file.read()
        print("读取文件", time.time()-start_time)
        time_steps = []
        headers = []
        ll_start = []
        nu_atoms = []
        ll_end = []
        for match in re.compile(RE_RUN_STEP).finditer(file_str):
            ll_end.append(match.start())
            time_steps.append(int(match.group(1)))

        for match in re.compile(RE_NU_ATOM).finditer(file_str):
            nu_atoms.append(int(match.group(1)))

        print("读取step", time.time()-start_time)
        for match in re.compile(RE_DUMP_DATA).finditer(file_str):
            ll_start.append(match.end())
            headers.append(match.group(1).strip().split())

        # print(ll_end)
        print("数据开始位置", time.time()-start_time)
        if steps is None:
            indices = range(len(time_steps))
        else:
            indices = np.where(np.isin(time_steps, steps))[0]
        print(indices)
        for i in indices:
            if i == len(time_steps)-1:
                tt = file_str[ll_start[i]:].strip()
            else:
                tt = file_str[ll_start[i]:ll_end[i+1]].strip()
            mat = np.fromstring(tt, dtype=float, sep=' ')
            data[time_steps[i]] = {
                "step": time_steps[i],
                "header": headers[i],
                "mat": mat.reshape(nu_atoms[i], int(mat.shape[0]/nu_atoms[i])),
            }

    # print("完成", time()-start)
    # print(len(data))
    # print(data[1002]["header"])
    # print(data[0]["step"])
    # print(data[0]["mat"][0])
    # print(data[-1]["step"])
    # print(data[-1]["mat"][-1])
    return data


def data2indexs(data, headers=None):
    """获取

    Args:
        data (_type_): {"step":int,"header":['id','type','vx','vy','vz'],"mat":[steps,atom_num]}
        headers (list, optional): _description_. Defaults to ['vx', 'vy', 'vz'].

    Returns:
        list: _description_
    """
    if headers is None:
        headers = ['vx', 'vy', 'vz']
    return [data["header"].index(col) for col in headers]


def str2mat(text):
    """矩阵，其实np.loadtxt应该也行

    Args:
        text (_type_): _description_

    Returns:
        _type_: _description_
    """
    mat = []
    for line in text.strip().split("\n"):
        mat_line = []
        for w in line.strip().split():
            mat_line.append(float(w))
        mat.append(mat_line)
    return np.array(mat)


def read_log(file_path):
    """读取log的run输出数据thermo_style

    Args:
        file_path (str): log 文件

    Returns:
        list: [{"step": int, "header": [], "mat": [[]]}]
    """
    with open(file_path, "r", encoding="utf8") as file:
        file_str = file.read()

        pattern = re.compile(LOG_RE_RUN_DATA, re.M)
        pattern_step = re.compile(LOG_RE_RUN_STEP)
        data = []

        for match in re.compile(LOG_RE_LOCATE_BLOCKS).finditer(file_str):
            block = match.group()
            line_first = block.split("\n")[0].strip()
            run_step = int(pattern_step.search(line_first).groups()[0].strip())
            for match in pattern.finditer(block):
                # header在这里
                header_str_lines = block[:match.start()].strip().split("\n")
                headers = header_str_lines[-1].strip().split()
                # 数据在这里
                mat_str = match.group().strip()
                # 根据header数目过滤掉一写错误的正则
                if len(headers) == len(mat_str.split("\n")[0].strip().split()):
                    mat = str2mat(mat_str)

                    data.append({
                        "step": run_step,
                        "header": headers,
                        "mat": mat,
                    })

                    break
        # print(data)\
        # print(len(data))
        return data


def get_vst(path_dump):
    """文件转vs数据

    Args:
        path_dump (_type_): _description_

    Returns:
        _type_: _description_
    """
    st = time.time()
    vst = []
    for _sk, sv in read_dumps(path_dump).items():
        indices = data2indexs(sv, ['vx', 'vy', 'vz'])
        vst.append(sv["mat"][:, indices])
    vst = np.array(vst)

    if vst.shape[0] < 1:
        print("错误: 无数据!")
        return

    print(f"读取速度数据：{time.time()-st:.2f}")
    return vst


def cal_vacf(path_dump, dlag=10):
    """根据dump的不同时刻各个原子各方向的速度数据计算vacf

    Args:
        path_dump (_type_): _description_
        dlag (int, optional): _description_. Defaults to 10.
    """
    st = time.time()
    vst = get_vst(path_dump)

    print(f"读取速度数据：{time.time()-st:.2f}")
    ndat = vst.shape[0]

#   set nlag as 1/10 of the total MD dumps
    nttt = ndat // dlag
    nlag = nttt if nttt > 0 else ndat // 10
    if nlag < 10:
        raise ValueError(f"错误：您的速度文件包含的数据太少！至少需要{10*dlag}！")
    print(f"nlag = {nlag}")

    ntotal = ndat + nlag
    fac = 1.0 / np.sqrt(ndat)
    sum_acf = np.zeros((nlag, vst.shape[2]))

    for itm in range(vst.shape[1]):
        for dim in range(vst.shape[2]):
            fftw_real = np.zeros(ntotal)
            fftw_real[:ndat] = vst[:, itm, dim] * fac

            # 正向FFT
            fftw_cmpx = fft(fftw_real)
            # 功率谱计算
            fftw_cmpx *= np.conj(fftw_cmpx)
            # 逆向FFT
            fftw_real_ifft = ifft(fftw_cmpx).real

            for i in range(nlag):
                sum_acf[i, dim] += fftw_real_ifft[i] / float(ndat - i)

    # 归一化
    for dim in range(vst.shape[2]):
        sum_acf[:, dim] /= sum_acf[0, dim]
    print(f"计算 vacf：{time.time()-st:.2f} | {sum_acf.shape}")

    return get_dt(nlag), sum_acf


def vacf2pdos(vacf, dt=0.001, df=0.01, fs_max=-1, fs_min=-1):
    """通过vacf计算pdos

    Args:
        vacf (_type_): _description_
        freq_range (_type_): _description_
        dt (float, optional): 两个输出之间dt. Defaults to 0.001.
        df (float, optional): _description_. Defaults to 0.01.

    Returns:
        _type_: _description_
    """
    nlag = len(vacf)
    ntotal = max(int(1/(2*dt*df)) + 1, nlag)

    dv = 1./(2*(ntotal-1)*dt)

    if fs_max <= ZERO:
        ndos = int(ntotal / 3)
    else:
        ndos = min(int(fs_max/dv)+1, ntotal)
    print(ndos)

    # 补零
    fft_in = np.zeros(ntotal)
    fft_in[:len(vacf)] = vacf
    pdos_ = dct(fft_in, type=1)[:ndos]
    freqs_ = np.linspace(0, ndos*dv, ndos)

    # 取部分

    freqs = freqs_[(fs_min < 0 or fs_min <= freqs_) &
                   (fs_max < 0 or freqs_ <= fs_max)]
    pdos = pdos_[(fs_min < 0 or fs_min <= freqs_) &
                 (fs_max < 0 or freqs_ <= fs_max)]

    # 归一化（可选，确保总积分归一）
    pdos /= np.trapezoid(pdos, freqs)

    return freqs, pdos


def get_dt(n):
    """不要1

    Args:
        n (_type_): _description_

    Returns:
        _type_: _description_
    """
    return np.linspace(0, 1, n+1)[:-1]
